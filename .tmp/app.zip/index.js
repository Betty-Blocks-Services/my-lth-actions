import { default as arrayCombine_1_0 } from './functions/array-combine/1.0';
import { default as arrayCount_1_0 } from './functions/array-count/1.0';
import { default as arrayFilter_1_0 } from './functions/array-filter/1.0';
import { default as arrayFind_1_0 } from './functions/array-find/1.0';
import { default as arrayJoin_1_0 } from './functions/array-join/1.0';
import { default as arrayMap_1_0 } from './functions/array-map/1.0';
import { default as arrayPush_1_0 } from './functions/array-push/1.0';
import { default as arrayReduce_1_0 } from './functions/array-reduce/1.0';
import { default as arraySplit_1_0 } from './functions/array-split/1.0';
import { default as importCsv_1_0 } from './functions/importCSV/1.0';
import { default as importCsv_1_1 } from './functions/importCSV/1.1';
import { default as importCsv_2_0 } from './functions/importCSV/2.0';
import { default as importCsv_2_1 } from './functions/importCSV/2.1';
import { default as importCsv_2_2 } from './functions/importCSV/2.2';
import { default as importCsv_2_3 } from './functions/importCSV/2.3';
import { default as importCsv_2_4 } from './functions/importCSV/2.4';
import { default as importCsv_3_0 } from './functions/importCSV/3.0';
import { default as importCsv_3_1 } from './functions/importCSV/3.1';
import { default as importCsv_3_2 } from './functions/importCSV/3.2';
import { default as importCsv_3_3 } from './functions/importCSV/3.3';
import { default as sharepointAccessToken_1_0 } from './functions/sharepoint-access-token/1.0';
import { default as sharepointDownloadFile_1_0 } from './functions/sharepoint-download-file/1.0';
import { default as sharepointFindDriveId_1_0 } from './functions/sharepoint-find-drive-id/1.0';
import { default as sharepointListFilesForDrive_1_0 } from './functions/sharepoint-list-files-for-drive/1.0';

const fn = {
  "arrayCombine 1.0": arrayCombine_1_0,
  "arrayCount 1.0": arrayCount_1_0,
  "arrayFilter 1.0": arrayFilter_1_0,
  "arrayFind 1.0": arrayFind_1_0,
  "arrayJoin 1.0": arrayJoin_1_0,
  "arrayMap 1.0": arrayMap_1_0,
  "arrayPush 1.0": arrayPush_1_0,
  "arrayReduce 1.0": arrayReduce_1_0,
  "arraySplit 1.0": arraySplit_1_0,
  "importCsv 1.0": importCsv_1_0,
  "importCsv 1.1": importCsv_1_1,
  "importCsv 2.0": importCsv_2_0,
  "importCsv 2.1": importCsv_2_1,
  "importCsv 2.2": importCsv_2_2,
  "importCsv 2.3": importCsv_2_3,
  "importCsv 2.4": importCsv_2_4,
  "importCsv 3.0": importCsv_3_0,
  "importCsv 3.1": importCsv_3_1,
  "importCsv 3.2": importCsv_3_2,
  "importCsv 3.3": importCsv_3_3,
  "sharepointAccessToken 1.0": sharepointAccessToken_1_0,
  "sharepointDownloadFile 1.0": sharepointDownloadFile_1_0,
  "sharepointFindDriveId 1.0": sharepointFindDriveId_1_0,
  "sharepointListFilesForDrive 1.0": sharepointListFilesForDrive_1_0,
};

export default fn;
