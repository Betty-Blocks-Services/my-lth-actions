import { default as arrayCombine_1_0 } from './functions/array-combine/1.0';
import { default as arrayFilter_1_0 } from './functions/array-filter/1.0';
import { default as arrayFind_1_0 } from './functions/array-find/1.0';
import { default as arrayJoin_1_0 } from './functions/array-join/1.0';
import { default as arrayMap_1_0 } from './functions/array-map/1.0';
import { default as arrayPush_1_0 } from './functions/array-push/1.0';
import { default as arraySplit_1_0 } from './functions/array-split/1.0';
import { default as sharepointAccessToken_1_0 } from './functions/sharepoint-access-token/1.0';
import { default as sharepointFindDriveId_1_0 } from './functions/sharepoint-find-drive-id/1.0';
import { default as sharepointListFilesForDrive_1_0 } from './functions/sharepoint-list-files-for-drive/1.0';

const fn = {
  "arrayCombine 1.0": arrayCombine_1_0,
  "arrayFilter 1.0": arrayFilter_1_0,
  "arrayFind 1.0": arrayFind_1_0,
  "arrayJoin 1.0": arrayJoin_1_0,
  "arrayMap 1.0": arrayMap_1_0,
  "arrayPush 1.0": arrayPush_1_0,
  "arraySplit 1.0": arraySplit_1_0,
  "sharepointAccessToken 1.0": sharepointAccessToken_1_0,
  "sharepointFindDriveId 1.0": sharepointFindDriveId_1_0,
  "sharepointListFilesForDrive 1.0": sharepointListFilesForDrive_1_0,
};

export default fn;
