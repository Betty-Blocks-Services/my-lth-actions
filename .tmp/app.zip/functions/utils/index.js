import { arrayBufferToBase64 } from "./base64";

export { arrayBufferToBase64 };
